from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .serializers import CategorySerilizer, addVehicleSerilizer,parkingSerilizer, parkingchargeSerilizer
from myparking.models import Category, addVehicle, parking_area_no, parking_charge, vehicle_type

# category--------------------------
#-------------------
@api_view(['GET'])
def Showallcategory(request):
    products = Category.objects.all()
    serializer = CategorySerilizer(products, many=True)
    return Response(serializer.data)


@api_view(['GET'])
def viewcategory(request, pk):
    products = Category.objects.get(id=pk)
    serializer = CategorySerilizer(products)

    return Response(serializer.data)

@api_view(['POST'])
def Createcategory(request):

    serializer = CategorySerilizer(data=request.data)
    if serializer.is_valid():
        serializer.save()

    return Response(serializer.data)

@api_view(['POST'])
def Updatecategory(request, pk):
    products = Category.objects.get(id=pk)
    serilizer = CategorySerilizer(instance=products, data=request.data)
    if serilizer.is_valid():
        serilizer.save()

    return Response(serilizer.data)


@api_view(['GET'])
def Deletecategory(request, pk):
    products = Category.objects.get(id=pk)
    products.delete()

    return Response("Item delete sucessfully...")



# add vehicle api--------------------
#--------------------------------

@api_view(['GET'])
def Showallvehicle(request):
    products = addVehicle.objects.all()
    serializer = addVehicleSerilizer(products, many=True)
    return Response(serializer.data)


@api_view(['GET'])
def viewvehicle(request, pk):
    products = addVehicle.objects.get(id=pk)
    serializer = addVehicleSerilizer(products)

    return Response(serializer.data)

@api_view(['POST'])
def Createvehicle(request):

    serializer = addVehicleSerilizer(data=request.data)
    if serializer.is_valid():
        serializer.save()

    return Response(serializer.data)

@api_view(['POST'])
def Updatevehicle(request, pk):
    products = addVehicle.objects.get(id=pk)
    serilizer = addVehicleSerilizer(instance=products, data=request.data)
    if serilizer.is_valid():
        serilizer.save()

    return Response(serilizer.data)


@api_view(['GET'])
def Deletevehicle(request, pk):
    products = addVehicle.objects.get(id=pk)
    products.delete()

    return Response("Item delete sucessfully...")

# parking area no api--------------------------------
#  -------------------------------


@api_view(['GET'])
def Showallparking(request):
    products = parking_area_no.objects.all()
    serializer = parkingSerilizer(products, many=True)
    return Response(serializer.data)


@api_view(['GET'])
def viewparking(request, pk):
    products = parking_area_no.objects.get(id=pk)
    serializer = parkingSerilizer(products)

    return Response(serializer.data)

@api_view(['POST'])
def Createparking(request):

    serializer = parkingSerilizer(data=request.data)
    if serializer.is_valid():
        serializer.save()

    return Response(serializer.data)

@api_view(['POST'])
def Updateparking(request, pk):
    products = parking_area_no.objects.get(id=pk)
    serilizer = parkingSerilizer(instance=products, data=request.data)
    if serilizer.is_valid():
        serilizer.save()

    return Response(serilizer.data)


@api_view(['GET'])
def Deleteparking(request, pk):
    products = parking_area_no.objects.get(id=pk)
    products.delete()

    return Response("Item delete sucessfully...")

# parking charge api---------------------
#-------------------------------------

@api_view(['GET'])
def Showallparkingcharge(request):
    products = parking_charge.objects.all()
    serializer = parkingchargeSerilizer(products, many=True)
    return Response(serializer.data)


@api_view(['GET'])
def viewparkingcharge(request, pk):
    products = parking_charge.objects.get(id=pk)
    serializer = parkingchargeSerilizer(products)

    return Response(serializer.data)

@api_view(['POST'])
def Createparkingcharge(request):

    serializer = parkingchargeSerilizer(data=request.data)
    if serializer.is_valid():
        serializer.save()

    return Response(serializer.data)

@api_view(['POST'])
def Updateparkingcharge(request, pk):
    products = parking_charge.objects.get(id=pk)
    serilizer = parkingchargeSerilizer(instance=products, data=request.data)
    if serilizer.is_valid():
        serilizer.save()

    return Response(serilizer.data)


@api_view(['GET'])
def Deleteparkingcharge(request, pk):
    products = parking_charge.objects.get(id=pk)
    products.delete()

    return Response("Item delete sucessfully...")





