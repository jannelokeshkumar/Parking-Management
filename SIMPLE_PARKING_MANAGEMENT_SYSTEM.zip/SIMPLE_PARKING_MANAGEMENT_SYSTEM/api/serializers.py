
from rest_framework import serializers
from myparking.models import Category, addVehicle,parking_area_no, parking_charge,vehicle_type

class CategorySerilizer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'

class addVehicleSerilizer(serializers.ModelSerializer):
    class Meta:
         model =addVehicle
         fields = '__all__'

class parkingSerilizer(serializers.ModelSerializer):
    class Meta:
         model =parking_area_no
         fields = '__all__'


class parkingchargeSerilizer(serializers.ModelSerializer):
    class Meta:
         model =parking_charge
         fields = '__all__'
