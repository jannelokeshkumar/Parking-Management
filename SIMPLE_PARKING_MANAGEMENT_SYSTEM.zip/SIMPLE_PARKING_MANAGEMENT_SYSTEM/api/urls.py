from django.urls import path
from .import views


urlpatterns = [

# category api
    path('category-list/', views.Showallcategory, name='category-list'),
    path('category-detail/<int:pk>', views.viewcategory, name='category-detail'),
    path('category-create/', views.Createcategory, name='category-create'),
    path('category-update/<int:pk>', views.Updatecategory, name='category-update'),
    path('category-delete/<int:pk>', views.Deletecategory, name='category-delete'),
# add vehicle api
    path('vehicle-list/', views.Showallvehicle, name='vehicle-list'),
    path('vehicle-detail/<int:pk>', views.viewvehicle, name='vehicle-detail'),
    path('vehicle-create/', views.Createvehicle, name='vehicle-create'),
    path('vehicle-update/<int:pk>', views.Updatevehicle, name='vehicle-update'),
    path('vehicle-delete/<int:pk>', views.Deletevehicle, name='vehicle-delete'),
# parking area no api
    path('parking-list/', views.Showallparking, name='parking-list'),
    path('parking-detail/<int:pk>', views.viewparking, name='parking-detail'),
    path('parking-create/', views.Createparking, name='parking-create'),
    path('parking-update/<int:pk>', views.Updateparking, name='parking-update'),
    path('parking-delete/<int:pk>', views.Deleteparking, name='parking-delete'),
# parjing charge api
    path('parkingcharge-list/', views.Showallparkingcharge, name='parkingcharge-list'),
    path('parkingcharge-detail/<int:pk>', views.viewparkingcharge, name='parkingcharge-detail'),
    path('parkingcharge-create/', views.Createparkingcharge, name='parkingcharge-create'),
    path('parkingcharge-update/<int:pk>', views.Updateparkingcharge, name='parkingcharge-update'),
    path('parkingcharge-delete/<int:pk>', views.Deleteparkingcharge, name='parkingcharge-delete'),

]