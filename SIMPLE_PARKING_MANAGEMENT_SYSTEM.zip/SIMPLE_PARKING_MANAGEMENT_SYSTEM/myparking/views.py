from django.contrib import auth
from django.shortcuts import render, redirect
from .models import addVehicle
from .models import Category
from django.db.models import Sum
from .forms import addVehiclesForms
from .forms import CategoryForms
from django.contrib.auth.models import User
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage

from django.http import HttpResponse

from django.template.loader import get_template
from xhtml2pdf import pisa

def dashbord(request):
    vehicle_Count = addVehicle.objects.all().count()
    departed_count = addVehicle.objects.filter(status=False).count()
    AvailableCategory_count = Category.objects.filter(status1=True).count()
    TotalEarning_count = addVehicle.objects.all().aggregate(Sum('parking_charge'))['parking_charge__sum']
    Totalparking_count = addVehicle.objects.all().count()

    context = {
        'vehicle_Count': vehicle_Count,
        'departed_count': departed_count,
        'AvailableCategory_count': AvailableCategory_count,
        'TotalEarning_count': TotalEarning_count,
        'Totalparking_count': Totalparking_count}
    return render(request, 'dashbord.html', context)


def VehiclesData(request):
    vehicles = addVehicle.objects.all()

    page_num = request.GET.get("page")
    paginator = Paginator(vehicles, 3)
    try:
        vehicles = paginator.page(page_num)
    except PageNotAnInteger:
        vehicles = paginator.page(1)
    except EmptyPage:
        vehicles = paginator.page(paginator.num_pages)

    context = {'vehicles': vehicles}

    return render(request, 'vehicles_views.html', context)

def addvehicles(request):
    form = addVehiclesForms()
    if request.method == "POST":
        form = addVehiclesForms(request.POST)
        if form.is_valid():
            form.save()
            return redirect('display_vehicles')

    context = {'form': form}
    return render(request, 'add_vehicles.html', context)


def CategoryData(request):
    category = Category.objects.all()

    page_num = request.GET.get("page")
    paginator = Paginator(category, 3)
    try:
        category = paginator.page(page_num)
    except PageNotAnInteger:
        category = paginator.page(1)
    except EmptyPage:
        category = paginator.page(paginator.num_pages)

    context = {'category': category}

    return render(request, 'category_views.html', context)


def addcategory(request):
    form = CategoryForms()
    if request.method == "POST":
        form = CategoryForms(request.POST)
        if form.is_valid():
            form.save()
            return redirect('display_category')

    context = {'form': form}
    return render(request, 'category.html', context)


def login(request):
    if request.method == 'POST':
        username = request.POST['username']   # ramu
        password = request.POST['password']   # ramu114212

        user = auth.authenticate(username=username, password=password)

        if user is not None:
            auth.login(request, user)
            print("login successfully")
            return redirect('dashbord')
        else:
            print("you provide invalid authentication")
            return redirect('login')
    else:
        return render(request,'login.html')

def updateCategory(request, pk):
    parking = Category.objects.get(id=pk)

    form = CategoryForms(instance=parking)

    if request.method == "POST":
        form = CategoryForms(request.POST, request.FILES, instance=parking)
        if form.is_valid():
            form.save()
            return redirect('display_category')

    context = {'form': form}

    return render(request, 'category.html', context)


def deleteCategory(request, pk):
    parking = Category.objects.get(id=pk)
    parking.delete()

    return redirect('display_category')

def Deactivate(request,pk):
    category = Category.objects.get(id=pk)
    category.status1 = False
    category.save()
    return redirect('display_category')

def Activate(request,pk):
    category = Category.objects.get(id=pk)
    category.status1 = True
    category.save()
    return redirect('display_category')

def search_category(request):
    if request.method == 'GET':
        query = request.GET.get('query')

        if query:
            cat = Category.objects.filter(parking_area_no1__contains=query)
            return render(request, 'category_views.html', {'category': cat})
        else:
            print('no information to show based on ur search')
            return render(request, 'category_views.html', {})


def Managevehicles(request):

    managevehicles = addVehicle.objects.all()

    page_num = request.GET.get("page")
    paginator = Paginator(managevehicles, 5)
    try:
        managevehicles = paginator.page(page_num)
    except PageNotAnInteger:
        managevehicles = paginator.page(1)
    except EmptyPage:
        managevehicles = paginator.page(paginator.num_pages)

    context = {'managevehicles': managevehicles}

    return render(request, 'manage_vehicles.html', context)

def search_manage(request):
    if request.method == 'GET':
        query = request.GET.get('query')

        if query:
            manage = addVehicle.objects.filter(id__contains=query)
            return render(request, 'manage_vehicles.html', {'managevehicles': manage})
        else:
            print('no information to show based on ur search')
            return render(request, 'manage_vehicles.html', {})

def search_vehicles(request):
    if request.method == 'GET':
        query = request.GET.get('query')

        if query:
            vehi = addVehicle.objects.filter(parking_area_no__contains=query)
            return render(request, 'vehicles_views.html', {'vehicles': vehi})
        else:
            print('no information to show based on ur search')
            return render(request, 'vehicles_views.html', {})

def search_main(request):
    if request.method == 'GET':
        query = request.GET.get('query')
        if query:
            v1 = addVehicle.objects.filter(parking_area_no__contains=query)
            return render(request, 'vehicles_views.html', {'vehicles': v1})
        else:
            print('no information to show based on ur search')
            return render(request, 'vehicles_views.html', {})

def deactive_manage(request,pk):
    add = addVehicle.objects.get(id=pk)
    add.status = False
    add.save()
    return redirect('managevehicles')

def active_manage(request,pk):
    add1 = addVehicle.objects.get(id=pk)
    add1.status = True
    add1.save()
    return redirect('managevehicles')


def register(request):
    if request.method == 'POST':  # true
        username = request.POST['username']  # username=ramu(is coming from reister table <input ==> name= 'username'>)
        email = request.POST['email']
        password1 = request.POST['password']
        password2 = request.POST['password2']

        if password1 == password2:
            if User.objects.filter(username=username).exists(): # ramu(database)=ramu
                print("User Name Exists! try anther username")
                return redirect('register')
            else:
                if User.objects.filter(email=email).exists():
                    print("email is already taken. try another one")
                    return redirect('register')
                else:
                    user = User.objects.create_user(username=username, email=email, password=password1)
                    user.save()
                    return redirect('login')
        else:
            print('password did not matched--')
            return redirect('register')

    else:
        return render(request, 'register.html')



def logout(request):
    if request.method == 'POST':
        auth.logout(request)
        print("logged out from website")
        return redirect('login')

def Change_password(request):
    if request.method == 'POST':
        oldpassword = request.POST['oldpassword'] #username=vandana is coming from rigister table
        Newpassword = request.POST['Newpassword']
        Renewpassword = request.POST['Renewpassword']
        if Newpassword!=Renewpassword:
            return render(request,'login..html',{"msg":"Newpassword and Renewpassword must match"})
        else:
            return redirect('login')
    return render(request,"account_settings.html")




# def show_vehicle(request):
#     addreport = addVehicle.objects.all()
#
#     context = {
#         'addreport':addreport
#     }
#
#     return render(request,'vehicles_views.html', context)





def render_pdf_view(request):
    report = addVehicle.objects.all()
    template_path ="reports.html"
    context = {'addreport': report}

    # Create a Django response object, and specify content_type as pdf
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'filename="addreport_report.pdf"'

    # find the template and render it.
    template = get_template(template_path)

    html = template.render(context)

    # create a pdf
    pisa_status = pisa.CreatePDF(
        html, dest=response)
    # if error then show some funny view
    if pisa_status.err:
        return HttpResponse('We had some errors <pre>' + html + '</pre>')
    return response















