from django.urls import path
from .import views
urlpatterns = [
    path('', views.login, name='login'),
    path('dashbord/', views.dashbord, name='dashbord'),
    path('display_vehicles/', views.VehiclesData, name='display_vehicles'),  # vehicle display
    path('addVehicles/', views.addvehicles,name='addvehicles'),  # form_vehicles
    path('display_category/', views.CategoryData, name='display_category'),  # category display
    path('addcategory/', views.addcategory, name='addcategory'),  # f0orm_category
    path('update/<int:pk>', views.updateCategory, name='update'),
    path('delete/<int:pk>', views.deleteCategory, name='delete'),
    path('activate/<int:pk>', views.Activate, name='activate'),
    path('deactivate/<int:pk>', views.Deactivate, name='deactivate'),
    path('search/', views.search_category, name='search'),
    path('managevehicles/', views.Managevehicles, name='managevehicles'),
    path('search_manage/', views.search_manage, name='search_manage'),
    path('search_vehicles/', views.search_vehicles, name='search_vehicles'),
    path('search_main/', views.search_main, name='search_main'),
    path('deactive_manage/<int:pk>', views.deactive_manage, name='deactive_manage'),
    path('active_manage/<int:pk>', views.active_manage, name='active_manage'),
    path('register',views.register, name='register'),
    path('logout', views.logout, name='logout'),
    path('Changepassword', views.Change_password, name='Changepassword'),
    # path('addreport', views.show_vehicle, name='addreport'),
    path('create-pdf', views.render_pdf_view, name='create-pdf'),

    path('report', views.render_pdf_view, name='report'),


]