from django import forms
from .models import addVehicle
from .models import Category


class addVehiclesForms(forms.ModelForm):
    class Meta:
        model = addVehicle
        fields = '__all__'


    # widgets = {
    #       'id': forms.TextInput(attrs={'class': 'form-control', 'size': 40}),
    #       'vehicle_no': forms.TextInput(attrs={'class': 'form-control'}),
    #       'parking_area_no': forms.TextInput(attrs={'class': 'form-control'}),
    #       'vehicles_type': forms.TextInput(attrs={'class': 'form-control'}),
    #       'parking_charge': forms.TextInput(attrs={'class': 'form-control'}),
    #       'status': forms.TextInput(attrs={'class': 'form-control'}),
    #       'arrival_time': forms.TextInput(attrs={'class': 'form-control'}),
    # }


class CategoryForms(forms.ModelForm):
    class Meta:
        model = Category
        fields = '__all__'

        widgets = {
            'cat_id': forms.TextInput(attrs={'class': 'form-control'}),
            'parking_area_no1': forms.TextInput(attrs={'class': 'form-control'}),
            'vehicle_type1': forms.TextInput(attrs={'class': 'form-control'}),
            'vehicle_limit': forms.TextInput(attrs={'class': 'form-control'}),
            'parking_charge1': forms.TextInput(attrs={'class': 'form-control'}),
            'status1': forms.TextInput(attrs={'class': 'form-control'}),
            'doc': forms.TextInput(attrs={'class': 'form-control'}),
        }





