from django.db import models
from datetime import datetime

# Create your models here.
class Category(models.Model):
    parking_area_no1 = models.IntegerField(null=False, blank=False)
    vehicle_type1 = models.CharField(max_length=200, null=False, blank=False)
    vehicle_limit = models.IntegerField(null=False, blank=False)
    parking_charge1 = models.DecimalField(max_digits=5, decimal_places=2)
    status1 = models.BooleanField(default=True)
    doc = models.DateTimeField(default=datetime.now, blank=True)


class parking_area_no(models.Model):
    parking_number = models.CharField(max_length=200, null=False, blank=False)
    def __int__(self):
        return self. parking_number

class parking_charge(models.Model):
    charge = models.CharField(max_length=200, null=False, blank=False)
    def __int__(self):
        return self.charge

class vehicle_type(models.Model):
    type = models.CharField(max_length=100, null=False, blank=False)
    def __str__(self):
        return self.type


class addVehicle(models.Model):

        vehicle_no = models.CharField(max_length=100, null=False, blank=False)

        parking_area_no = models.ForeignKey(parking_area_no, on_delete=models.CASCADE, default=True, null=False)

        vehicle_type = models.ForeignKey(vehicle_type, on_delete=models.CASCADE, default=True, null=False)

        parking_charge = models.ForeignKey(parking_charge, on_delete=models.CASCADE, default=True, null=False)

        status = models.BooleanField(default=True)
        arrival_time = models.DateTimeField(default=datetime.now, blank=True)

