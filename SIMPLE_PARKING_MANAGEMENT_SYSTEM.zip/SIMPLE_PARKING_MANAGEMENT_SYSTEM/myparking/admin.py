from django.contrib import admin
from .models import addVehicle
from .models import Category

from .models import parking_area_no
from .models import parking_charge
from .models import vehicle_type


# Register your models here.


class VehicleAdmin(admin.ModelAdmin):
    list_display = ('vehicle_no', 'parking_area_no', 'vehicle_type', 'parking_charge', 'status', 'arrival_time')
    list_editable = ('status',)

class CategoryAdmin(admin.ModelAdmin):
    list_display = ('parking_area_no1', 'vehicle_type1', 'vehicle_limit', 'parking_charge1', 'status1', 'doc')
    list_editable = ('status1',)


admin.site.register(addVehicle, VehicleAdmin)
admin.site.register(Category, CategoryAdmin)
admin.site.register(parking_area_no)
admin.site.register(parking_charge)
admin.site.register(vehicle_type)

